import React, { useState } from "react";
import BillUploadCard from "./BillUploadCard";
import BillResults from "./BillResults";

export default function BillAnalyzer() {
  const [analysis, setAnalysis] = useState(null);
  const [appealLetter, setAppealLetter] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleAnalysis = async (file) => {
    setLoading(true);

    const formData = new FormData();
    formData.append("file", file);

    // 1. Analyze the bill
    const analysisRes = await fetch("http://localhost:8080/analyze-bill", {
      method: "POST",
      body: formData,
    });

    const analysisData = await analysisRes.json();
    setAnalysis(analysisData);

    // 2. Draft appeal letter
    const appealRes = await fetch("http://localhost:8080/draft-appeal-letter", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        findings: analysisData,
        emotion: "neutral",
      }),
    });

    const appealData = await appealRes.json();
    setAppealLetter(appealData.letter);

    setLoading(false);
  };

  return (
    <div className="p-6">
      <h1 className="text-xl font-bold mb-4">Medical Bill Analyzer</h1>

      <BillUploadCard onUpload={handleAnalysis} loading={loading} />

      {analysis && (
        <BillResults analysis={analysis} appealLetter={appealLetter} />
      )}
    </div>
  );
}
